﻿namespace Microsoft.Azure.DevOps.ClientSamples.WorkItemTracking
{
    [ClientSample]
    public class ReportingSample : ClientSample
    {


    }
}
